 #include <cstdlib>
#include <iostream>
#include <map>
#include <string>
 
#include "TChain.h"
#include "TFile.h"
#include "TTree.h"
#include "TString.h"
#include "TObjString.h"
#include "TSystem.h"
#include "TROOT.h"
 
#include "TMVA/Factory.h"
#include "TMVA/DataLoader.h"
#include "TMVA/Tools.h"
#include "TMVA/TMVAGui.h"





void tmva_training() {


auto outputFile = TFile::Open("TMVAOutputCV.root", "RECREATE");

TMVA::Factory factory("TMVAClassification", outputFile,
                        "!V:ROC:!Correlations:!Silent:Color:"
                        "!DrawProgressBar:AnalysisType=Classification");

TMVA::DataLoader loader("dataset");

//loader.AddVariable("EventId", 'F');   // EventId (Long64_t)
loader.AddVariable("DER_mass_MMC", 'F');      // DER_mass_MMC (double)
loader.AddVariable("DER_mass_transverse_met_lep", 'F');       // DER_mass_transverse_met_lep (double)
loader.AddVariable("DER_mass_vis", 'F');      // DER_mass_vis (double)
loader.AddVariable("DER_pt_h", 'F');          // DER_pt_h (double)
loader.AddVariable("DER_deltaeta_jet_jet", 'F');      // DER_deltaeta_jet_jet (double)
loader.AddVariable("DER_mass_jet_jet", 'F');          // DER_mass_jet_jet (double)
loader.AddVariable("DER_prodeta_jet_jet", 'F');       // DER_prodeta_jet_jet (double)
loader.AddVariable("DER_deltar_tau_lep", 'F');        // DER_deltar_tau_lep (double)
loader.AddVariable("DER_pt_tot", 'F');        // DER_pt_tot (double)
loader.AddVariable("DER_sum_pt", 'F');        // DER_sum_pt (double)
loader.AddVariable("DER_pt_ratio_lep_tau", 'F');      // DER_pt_ratio_lep_tau (double)
loader.AddVariable("DER_met_phi_centrality", 'F');    // DER_met_phi_centrality (double)
loader.AddVariable("DER_lep_eta_centrality", 'F');    // DER_lep_eta_centrality (double)
loader.AddVariable("PRI_tau_pt", 'F');        // PRI_tau_pt (double)
loader.AddVariable("PRI_tau_eta", 'F');       // PRI_tau_eta (double)
loader.AddVariable("PRI_tau_phi", 'F');       // PRI_tau_phi (double)
loader.AddVariable("PRI_lep_pt", 'F');        // PRI_lep_pt (double)
loader.AddVariable("PRI_lep_eta", 'F');       // PRI_lep_eta (double)
loader.AddVariable("PRI_lep_phi", 'F');       // PRI_lep_phi (double)
loader.AddVariable("PRI_met", 'F');   // PRI_met (double)
loader.AddVariable("PRI_met_phi", 'F');       // PRI_met_phi (double)
loader.AddVariable("PRI_met_sumet", 'F');     // PRI_met_sumet (double)
loader.AddVariable("PRI_jet_num", 'F');       // PRI_jet_num (Long64_t)
loader.AddVariable("PRI_jet_leading_pt", 'F');        // PRI_jet_leading_pt (double)
loader.AddVariable("PRI_jet_leading_eta", 'F');       // PRI_jet_leading_eta (double)
loader.AddVariable("PRI_jet_leading_phi", 'F');       // PRI_jet_leading_phi (double)
loader.AddVariable("PRI_jet_subleading_pt", 'F');     // PRI_jet_subleading_pt (double)
loader.AddVariable("PRI_jet_subleading_eta", 'F');    // PRI_jet_subleading_eta (double)
loader.AddVariable("PRI_jet_subleading_phi", 'F');    // PRI_jet_subleading_phi (double)
loader.AddVariable("PRI_jet_all_pt", 'F');    // PRI_jet_all_pt (double)
//loader.AddVariable("Weight", 'F');    // Weight (double)
//loader.AddVariable("Label", 'F');     // Label (std::string)
//loader.AddVariable("KaggleSet", 'F');         // KaggleSet (std::string)
//loader.AddVariable("KaggleWeight", 'F');      // KaggleWeight (double)


// Set individual event weights (variables must exist in original TTree)
loader.SetSignalWeightExpression("Weight"); 
loader.SetBackgroundWeightExpression("Weight");

//Setup dataset
auto signalFile = TFile::Open(
      "atlas-higgs-challenge-2014-v2-sig.root");

auto backgroundFile = TFile::Open(
      "atlas-higgs-challenge-2014-v2-bkg.root");


// Get the signal and background trees from TFile source(s);
// multiple trees can be registered with the Factory

TTree* sigTree = (TTree*)signalFile->Get("tree");
TTree* bkgTree = (TTree*)backgroundFile->Get("tree");

// Set the event weights per tree (these weights are applied in
// addition to individual event weights that can be specified)
Double_t sigWeight = 1.0; //overall weight
Double_t bkgWeight = 1.0; //overall weight

TCut mycuts,mycutb;

// Register the trees
loader.AddSignalTree( sigTree, sigWeight );
loader.AddBackgroundTree( bkgTree, bkgWeight );


loader.PrepareTrainingAndTestTree(mycuts, mycutb,
                               "nTrain_Signal=10000:nTrain_Background=20000:NTest_Signal=0:NTest_Background=0");



factory.BookMethod(&loader, TMVA::Types::kCuts, "Cuts",
                           "!H:!V:FitMethod=MC:EffSel:SampleSize=200000:VarProp=FSmart" );
 
   

// Boosted Decision Trees
factory.BookMethod(&loader, TMVA::Types::kBDT, "BDT",
      "!V:NTrees=200:MinNodeSize=2.5%:MaxDepth=2:BoostType=AdaBoost:"
      "AdaBoostBeta=0.5:UseBaggedBoost:BaggedSampleFraction=0.5:"
      "SeparationType=GiniIndex:nCuts=20");

// Multi-Layer Perceptron (Neural Network)
factory.BookMethod(&loader, TMVA::Types::kMLP, "MLP",
                     "!H:!V:NeuronType=tanh:VarTransform=N:NCycles=100:"
                     "HiddenLayers=N+5:TestRate=5:!UseRegulator");
//Fisher
factory.BookMethod(&loader, TMVA::Types::kFisher, "Fisher", "H:!V:Fisher:VarTransform=None:CreateMVAPdfs:PDFInterpolMVAPdf=Spline2:NbinsMVAPdf=50:NsmoothMVAPdf=10" );

//Training
factory.TrainAllMethods();

//Test and Evaluation
factory.TestAllMethods();
factory.EvaluateAllMethods();


}