#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"
using namespace RooFit;

void rarest_b0_decay() {

    RooWorkspace *w = new RooWorkspace("w","w");

    //Define observable - invariant mass
    RooRealVar x("x","invariant mass",5084,5541);
    w->import(x);

    //Read data set
    RooDataSet data = *RooDataSet::read("rarest_b0_decay.dat", x, "v");

    //Plot data set
    RooPlot *xframe = x.frame();
    data.plotOn(xframe);
    

    //Define the model
    w->factory("Exponential::bkg(x,c[-0.001,-1,-0.000001])");
    w->factory("Gaussian::b0(x,mean_b0[5300,5000,5500],sigma[10,1,20])");
    w->factory("Gaussian::b0s(x,mean_b0s[5350,5000,5500],sigma)");
    
    RooRealVar f_b0("f_b0","f_b0",0.1,0,1);
    RooRealVar f_b0s("f_b0s","f_b0s",0.1,0,1);
    w->import(f_b0);
    w->import(f_b0s);

    w->factory("SUM::model(f_b0*b0,f_b0s*b0s,bkg)");

    //Fit model to data
    RooFitResult* r = w->pdf("model")->fitTo(data,Save());

    //Plot single components
    w->pdf("model")->plotOn(xframe,Components("b0"),LineColor(kRed));
    w->pdf("model")->plotOn(xframe,Components("b0s"),LineColor(kBlue));
    w->pdf("model")->plotOn(xframe,Components("bkg"),LineColor(kGreen));
    w->pdf("model")->plotOn(xframe,LineColor(kCyan));

    //export the model to file
    w->writeToFile("workspace.root");

    xframe->Draw();

    //Residual and pull distributions

    //Construct a histogram with the residuals of the data w.r.t. the curve
   RooHist *hresid = xframe->residHist();
 
   // Construct a histogram with the pulls of the data w.r.t the curve
   RooHist *hpull = xframe->pullHist();
 
   // Create a new frame to draw the residual distribution and add the distribution to the frame
   RooPlot *xframe2 = x.frame(Title("Residual Distribution"));
   xframe2->addPlotable(hresid, "P");
 
   // Create a new frame to draw the pull distribution and add the distribution to the frame
   RooPlot *xframe3 = x.frame(Title("Pull Distribution"));
   xframe3->addPlotable(hpull, "P");

   TCanvas *c1 = new TCanvas();
   c1->Divide(2);
   c1->cd(1);
   xframe2->Draw("B");
   c1->cd(2);
   xframe3->Draw("B");

   //Correlation matrix

    TCanvas* c = new TCanvas();
    gStyle->SetPalette(1);
    r->correlationHist()->Draw("colz");
    c->Print("corr.png");
    
    //CONTROL REGION


    //Control region model
    
    TFile *fw = new TFile("workspace.root");
    //fw->ls();

    RooWorkspace *w_ctl;

    //import the initial model - copy
    fw->GetObject("w",w_ctl);
    w_ctl->Print();

    //Read the new file
    RooDataSet data2 = *RooDataSet::read("rarest_b0_decay.dat", x, "v");

    //control region variable
    RooRealVar x_ctl("x_ctl","observables - control region",4000,5000);
    w_ctl->import(x_ctl);
    w_ctl->factory("Exponential::model_ctl(x_ctl,c)");
    w_ctl->var("c")->setVal(-1.0*(1e-3));

    //Generate data
    RooDataSet *data_ctl =(w_ctl->pdf("model_ctl"))->generate(x_ctl,1e4);

    // Define category to distinguish physics and control samples events
    RooCategory sample("sample", "sample");
    sample.defineType("physics");
    sample.defineType("control");

    RooDataSet combData("combData","combined data", RooArgSet(x,x_ctl),
                        Index(sample), Import({{"physics", &data}, {"control", data_ctl}})
                                                                                        );

    // Construct a simultaneous pdf using category sample as index
    RooSimultaneous simPdf("simPdf", "simultaneous pdf", sample);

    // Associate model with the physics state and model_ctl with the control state
    simPdf.addPdf(*(w_ctl->pdf("model")), "physics");
    simPdf.addPdf(*(w_ctl->pdf("model_ctl")), "control");

    // P e r f o r m   a   s i m u l t a n e o u s   f i t
    // ---------------------------------------------------
 
    // Perform simultaneous fit of model to data and model_ctl to data_ctl
    simPdf.fitTo(combData);

    // P l o t   m o d e l   s l i c e s   o n   d a t a    s l i c e s
    // ----------------------------------------------------------------
 
    // Make a frame for the physics sample
    RooPlot *frame1 = x.frame(Bins(30),Title("Physics sample"));
 
    // Plot all data tagged as physics sample
    combData.plotOn(frame1, Cut("sample==sample::physics"));

    // Plot "physics" slice of simultaneous pdf.
    // NBL You _must_ project the sample index category with data using ProjWData
    // as a RooSimultaneous makes no prediction on the shape in the index category
    // and can thus not be integrated.
    // In other words: Since the PDF doesn't know the number of events in the different
    // category states, it doesn't know how much of each component it has to project out.
    // This information is read from the data.
    simPdf.plotOn(frame1, Slice(sample, "physics"), ProjWData(sample, combData));
   
 
    // The same plot for the control sample slice
    RooPlot *frame2 = x_ctl.frame(Bins(30),Title("Control sample"));
    combData.plotOn(frame2, Cut("sample==sample::control"));
    simPdf.plotOn(frame2, Slice(sample, "control"), ProjWData(sample, combData));
 

    TCanvas *c2 = new TCanvas("simultaneouspdf", "simultaneouspdf", 800, 400);
    c2->Divide(2);
    c2->cd(1);
    gPad->SetLeftMargin(0.15);
    frame1->GetYaxis()->SetTitleOffset(1.4);
    frame1->Draw();
    c2->cd(2);
    gPad->SetLeftMargin(0.15);
    frame2->GetYaxis()->SetTitleOffset(1.4);
    frame2->Draw();



    

}