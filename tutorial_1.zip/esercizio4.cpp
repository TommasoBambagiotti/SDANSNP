#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "RooProdPdf.h"
#include "RooFormulaVar.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"

using namespace std;
using namespace RooFit;

void esercizio4_new() {

    RooRealVar x1("x1","x1",0,1);
    RooRealVar x2("x2","x2",0,1);
    RooRealVar x3("x3","x3",0,1);
    RooRealVar x4("x4","x4",0,1);
    RooRealVar x5("x5","x5",0,1);

    RooUniform u1("u1","u1",x1);
    RooUniform u2("u2","u2",x2);
    RooUniform u3("u3","u3",x3);
    RooUniform u4("u4","u4",x4);
    RooUniform u5("u5","u5",x5);

    RooProdPdf p("p","product of 5 uniform pdf", RooArgSet(u1,u2,u3,u4,u5));

    // Construct formula to calculate the sum events
    RooFormulaVar fsum("fsum","x1+x2+x3+x4+x5", RooArgList(x1, x2,x3,x4,x5));

    //Add column with variable xsum to previously generated dataset    
    RooDataSet* data = p.generate(RooArgSet(x1,x2,x3,x4,x5),1e4);
    auto xsum = (RooRealVar*) data->addColumn(fsum);

    //Gaussian 
    RooRealVar mu("mu","mean",2.5,0,5);
    RooRealVar sigma("sigma","dev. std.",0.65,0,10);
    RooGaussian g("g","gaussian",*xsum,mu,sigma);

    //Fit
    g.fitTo(*data);

    //Plot
    auto plot = xsum->frame(Bins(40), Title("Sum of Random variables"), Range(0., 5.));
    data->plotOn(plot);
    g.plotOn(plot);

    plot->Draw();


}