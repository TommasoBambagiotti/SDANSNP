#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"
using namespace RooFit;


// inspired by https://root.cern/doc/master/rf101__basics_8C.html

int esercizio2()
{
  // S e t u p  a GAUSSIAN   m o d e l
  // --------------------------------------
 
  // Declare variables x,mean,sigma,
  // with associated name, title, initial value and allowed range



  RooRealVar x("x","x",0.,100.);
  RooRealVar tau("tau","mean life",4.5,0,8);
  RooFormulaVar c("c","-1/@0",RooArgList(tau));

  // Build Gaussian pdf in terms of x,mean, sigma

  RooExponential e("e","exponential",x,c);
  
 
  // G e n e r a t e   e v e n t s
  // -----------------------------
 
   // Generate a dataset of 1000 events in x from Exponential
   x.setBins(200);
  RooDataHist* hdata = e.generateBinned(x, 1000);

  // F i t   m o d e l   t o   d a t a
  // -----------------------------
  
  // Fit pdf to data
  e.fitTo(*hdata); 
  // Print values of mean and sigma (that now reflect fitted values and errors)
  c.Print();
  // Draw all frames on a canvas
  RooPlot* xframe = x.frame();
  xframe->SetTitle("Exponential fit");
  hdata->plotOn(xframe);
  e.plotOn(xframe);
  xframe->Draw();


  return 0;
}
