#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"
using namespace RooFit; 

//breitWignerModel declaration
void breitWignerModel(RooWorkspace &w);
  
void esercizio3_w() { 


  //create new workspace
  RooWorkspace w("w");
  //open the file and import massaB0
  auto f = TFile::Open("B0sInvariantMass.root");
  auto h = static_cast<TH1F*>(f->Get("massaB0"));

  RooRealVar x("x","observable",5,6);
  x.setBins(200);
  RooDataHist dh{"dh", "LHCb data", x, Import(*h)};
  
  //import x in the workspace
  w.import(x);

  //import model
  breitWignerModel(w);

  //FIT
  w.pdf("bw")->fitTo(dh); 

  //Gaussian  
  RooRealVar mu("mu","mu",5,0,10.);
  RooRealVar sigma("sigma","dev. std.",0.1,0.,1);
  RooGaussian g("g","gaussian",x,mu,sigma);

  //Fit Gaussian
  g.fitTo(dh);

  //Plot data, fitted BW and Gaussian
  RooPlot* xframe = x.frame();

  dh.plotOn(xframe);
  w.pdf("bw")->plotOn(xframe,LineColor(kRed));
  g.plotOn(xframe,LineColor(kBlue));
  xframe->Draw();
}

void breitWignerModel(RooWorkspace &w) {

  //Breit-Wigner model  
  RooRealVar mean("mean","mean",5,0,10);
  RooRealVar width("width","width",0.1,0,1);
  RooBreitWigner bw("bw","breit-wigner",*w.var("x"),mean,width);
  w.import(bw);
}