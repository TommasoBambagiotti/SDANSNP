#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"
using namespace RooFit;


// inspired by https://root.cern/doc/master/rf101__basics_8C.html

int esercizio1()
{
  // S e t u p  a GAUSSIAN   m o d e l
  // --------------------------------------
 
  // Declare variables x,mean,sigma,
  // with associated name, title, initial value and allowed range

  RooRealVar x("x","observable",0.,-10.,10.);
  RooRealVar mu("mu","mean",0,-10,10);
  RooRealVar sigma("sigma","dev.std.",1,0.1,10);

  // Build Gaussian pdf in terms of x,mean, sigma

  RooGaussian g("g","gaus",x,mu,sigma);
  
  // Construct plot frame in 'x'
  
  RooPlot* xframe = x.frame();

  // P l o t   m o d e l   a n d   c h a n g e   p a r a m e t e r   v a l u e s
  // ---------------------------------------------------------------------------
 
  // Plot Gaussian in frame (i.e. in x)
   

   g.plotOn(xframe);
   
  // Change the value of sigma to 3
   sigma.setVal(3);
  // Plot Gaussian in frame (i.e. in x) and draw frame on canvas
    // Make a second plot frame in x and draw both the
  RooPlot* xframe2 = x.frame();
  g.plotOn(xframe2);

  // G e n e r a t e   e v e n t s
  // -----------------------------
 
  // Generate a dataset of 1000 events in x from Gaussian
  RooDataSet* data = g.generate(x,1e4);

  // F i t   m o d e l   t o   d a t a
  // -----------------------------
  
  // Fit pdf to data
  g.fitTo(*data); 
  // Print values of mean and sigma (that now reflect fitted values and errors)
  mu.Print();
  sigma.Print();
  // Draw all frames on a canvas
  RooPlot* xframe3 = x.frame();

  data->plotOn(xframe3);
  g.plotOn(xframe3);

  // Draw all frames on a canvas
   TCanvas *c = new TCanvas("c", "Esercizio 1", 800, 400);
   c->Divide(3);
   c->cd(1);
   gPad->SetLeftMargin(0.15);
   xframe->SetTitle("Gaussian, sigma = 1");
   xframe->GetYaxis()->SetTitleOffset(1.6);
   xframe->Draw();
   c->cd(2);
   gPad->SetLeftMargin(0.15);
   xframe2->SetTitle("Gaussian, sigma = 3");
   xframe2->GetYaxis()->SetTitleOffset(1.6);
   xframe2->Draw();
   c->cd(3);
   gPad->SetLeftMargin(0.15);
   xframe3->SetTitle("Gaussian, fit");
   xframe3->GetYaxis()->SetTitleOffset(1.6);
   xframe3->Draw();


  return 0;
}
