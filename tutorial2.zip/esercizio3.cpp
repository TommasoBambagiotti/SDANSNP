#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "RooConstVar.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "RooHist.h"
#include "TAxis.h"
using namespace RooFit;

void esercizio3() {

    RooWorkspace w;

    //Landau distributions
    w.factory("Landau::l1(x[0,1],mean_l[0.2,0,0.4],sigma_l[0.02,0.005,0.05])");
    w.factory("Landau::l2(x,mean_l,sigma_l)");

    //convolution of two Landau
    w.factory("NCONV::lconv(x,l1,l2)");

    //detector resolution
    w.factory("Gaussian::d(x,mean_d[0,0,0.4],sigma_d[0.04,0.005,0.08])");

    //signal and background convolved with a gaussian
    w.factory("NCONV::sig1(x,lconv,d)");
    w.factory("NCONV::sig2(x,l1,d)");

    //SiMP dark current
    w.factory("Exponential::bkg(x,c[-50,-400,-10])");
    

    //model
    RooRealVar fsig1("fsig1","expected signal",0.1,0,1);
    RooRealVar fsig2("fsig2","expected signal",0.1,0,1);
    w.import(fsig1);
    w.import(fsig2);


    w.factory("SUM::model(fsig1*sig1,fsig2*sig2,bkg)");
    

    //importing data
    //RooRealVar t("t","t",0,1);
    w.var("x")->setBins(50);
    RooDataHist data{"data", "data", *w.var("x")};
    ifstream file("enubet_histo.dat");
    double val, weight;
    while (!file.eof()) {
        file >> val >> weight;
        w.var("x")->setVal(val); 
        data.set(*w.var("x"), weight);
        }

    //Fit the model to the data
    w.pdf("model")->fitTo(data);

    //Plots
    RooPlot* xframe = w.var("x")->frame();
    data.plotOn(xframe);
    w.pdf("model")->plotOn(xframe,Components("sig1"),LineColor(kBlue));
    w.pdf("model")->plotOn(xframe,Components("sig2"),LineColor(kGreen));
    w.pdf("model")->plotOn(xframe,Components("bkg"),LineColor(kRed));
    xframe->Draw();



    }



