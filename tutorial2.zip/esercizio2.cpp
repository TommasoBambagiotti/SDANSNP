#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"
using namespace RooFit;


void esercizio2() {

    RooWorkspace w;

    RooRealVar x("x","x",0,10);

    //signal
    RooRealVar mean("mean","signal mean",5.);
    RooRealVar sigma("sigma","signal std. dev.",0.5);
    RooGaussian sig("sig","signal",x,mean,sigma);
    w.import(sig);

    w.var("mean")->setConstant(true);
    w.var("sigma")->setConstant(true);


   //background
    RooRealVar tau("tau","mean life",4.5,0,8);
    RooFormulaVar c("c","-1/@0",RooArgList(tau));
    
    RooExponential bkg("bkg","exponential",x,c);
    w.import(bkg);

    //signal and background number of events
    RooRealVar nsig("nsig","expected signal",100,0,1000);
    RooRealVar nbkg("nbkg","exptected background",100,0,1000);
    w.import(nsig);
    w.import(nbkg);

    //model
    w.factory("SUM::m(nsig*sig,nbkg*bkg)");

    //export model
    w.writeToFile("workspace.root");

    //Data generation
    RooDataSet *data = w.pdf("m")->generate(x,1e3);

    //Fit to data
    w.pdf("m")->fitTo(*data);

    //Plots
    RooPlot* xframe = x.frame();

    data->plotOn(xframe);

    w.pdf("m")->plotOn(xframe,Components("bkg"),LineColor(kGreen));
    
    w.pdf("m")->plotOn(xframe,Components("sig"),LineColor(kBlue));

    xframe->SetTitle("Extended model");

    xframe->Draw();




}
