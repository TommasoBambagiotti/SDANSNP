#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"
using namespace RooFit;



void esercizio1() {

    RooWorkspace w;
    
    RooRealVar x ("x","x",0,10);

    //signal
    
    RooRealVar mean("mean","gaussian mean",5.);
    RooRealVar sigma("sigma","gaussian std. dev.",0.5);

    RooGaussian sig("sig","gaussian",x,mean,sigma);
    w.import(sig);
    w.var("mean")->setConstant(true);
    w.var("sigma")->setConstant(true);

    //background
    RooRealVar tau("tau","mean life",4.5,0,8);
    RooFormulaVar c("c","-1/@0",RooArgList(tau));

    RooExponential bkg("bkg","exponential",x,c);
    w.import(bkg);

    //composite model

    //signal fraction
    RooRealVar nsig("nsig","expcted signal",0.5,0,1);
    w.import(nsig);

    //construct the model
    w.factory("SUM::m(nsig*sig,bkg)");

    //Generate data
    RooDataSet *data =w.pdf("m")->generate(x,1e3);

    //Fit to the data
    w.pdf("m")->fitTo(*data);

    //Plot the model
    RooPlot *xframe = x.frame();
    data->plotOn(xframe);
    w.pdf("m")->plotOn(xframe,Components(bkg),LineColor(kRed));
    w.pdf("m")->plotOn(xframe,Components(sig));
    xframe->SetTitle("Bkg. + gaussian sig. model");
    xframe->Draw();
    



}
