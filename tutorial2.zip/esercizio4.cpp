#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "RooFormulaVar.h"
#include "RooGenericPdf.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"
using namespace RooFit;

void esercizio4() {

    //observables
    RooRealVar cos_z("cos_z","zenith angles",-1.,0.);
    RooRealVar log_e("log_e","neutrino energy",0.8,1.75);

    //set number of bins
    cos_z.setBins(8);
    log_e.setBins(8);
    

    //Create histogram
    RooDataHist data("data","data",RooArgSet(cos_z,log_e));

    //Read data from file
    ifstream file("icecube.dat");
    double x1, x2, y1, y2;
    int counts;
    while (!file.eof()) {
    file >> x1 >> x2 >> y1 >> y2 >> counts;
    cos_z.setVal((x1+x2)/2);
    log_e.setVal((y1+y2)/2);
    data.set(RooArgSet(cos_z,log_e), counts);
    }

    data.Print("V");
    data.get(1)->Print();
    
    //Mixing and dm2
    //parameters--->it's useful to set initial values
    RooRealVar dm2 ("dm2","mass splitting",2e-3,0.00001,0.03); //eV2
    RooRealVar mix ("mix","mixing term",0.9,0.00001,1);

    //Length
    RooFormulaVar L("L","100-13000*@0",RooArgList(cos_z));
    
    //Energy
    RooFormulaVar en("en","pow(10,@0)",RooArgList(log_e));

    //Normalized pdf
    RooGenericPdf model("model","1-(@0)*sin((1.267*(@1)*(@2))/(@3))*sin((1.267*(@1)*(@2))/(@3))",RooArgList(mix,dm2,L,en));
    
    //save parameters before fit
    RooArgSet* params = model.getParameters(RooArgList(cos_z,log_e));
    RooArgSet* params_before_fit = params->snapshot();
    
    //FIT
    model.fitTo(data);
    
    //save parameters after fit
    RooArgSet* params_after_fit = params->snapshot();
   
    //signal range
    TCanvas* c = new TCanvas();
    c->Divide(4,2);
    

    auto ebinning = log_e.getBinning().clone();
    for (int i=0;i < ebinning->numBins(); i++) {
        
      //set a range for energy --> give to this range a name
      log_e.setRange("sig",ebinning->binLow(i),ebinning->binHigh(i));


      RooPlot * fx = cos_z.frame();
      
      data.plotOn(fx,CutRange("sig"));

      //plot before fit
      *params = *params_before_fit;
      model.plotOn(fx, ProjectionRange("sig"),LineColor(kBlue));
      
      //plot after fit
      *params = *params_after_fit;
      model.plotOn(fx,ProjectionRange("sig"),LineColor(kRed));
      c->cd(i+1);
      fx->Draw();

    }

    //PART 3 - MINUIT


    // Construct function object representing –log(L)
    RooAbsReal* nll = model.createNLL(data) ;

    // Start Minuit session on above nll
    RooMinuit m(*nll) ;

    //enable verbose logging
    m.setVerbose(kTRUE);

    // MIGRAD likelihood minimization
    m.migrad() ;

    // Print values of all parameters, that reflect values (and error estimates)
    // that are back propagated from MINUIT
    
    model.getParameters(dm2)->Print("s");
    model.getParameters(mix)->Print("s");

    //disable verbose logging
    m.setVerbose(kFALSE);

    // Run HESSE error analysis
    m.hesse() ;
   
    model.getParameters(dm2)->Print("s");
    model.getParameters(mix)->Print("s");

    // Run MINOS on sigma_g2 parameter only
    m.minos(dm2);
    
    model.getParameters(dm2)->Print("s");

    // Save a snapshot of the fit result.
    RooFitResult* r = m.save() ;
    
    cout << "PLOT3" << "\n";
    // Print the fit result snapshot
    r->Print("v") ;


    // Make contour plot of dm2 vs mix at 1,2,3 sigma
    TCanvas* c2 = new TCanvas();
    RooPlot* frame = m.contour(mix,dm2,1,2,3);
    frame->SetTitle("RooMinuit contour plot");
    frame->GetYaxis()->SetRangeUser(0.0009,0.0014);
    frame->GetXaxis()->SetRangeUser(0.4,0.9);
    frame->Draw();

}