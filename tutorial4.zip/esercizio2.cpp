//use the asymptotic formula to calculate the excess significance, not the frequentistics one!!
//mu is the parameter of interest
//mass in not neither a parameter of interest nor a nuissance parameter
//CB = gaussian + power law
#include "RooRealVar.h"
#include "RooDataSet.h"
#include "RooDataHist.h"
#include "RooGaussian.h"
#include "RooPolynomial.h"
#include "RooCBShape.h"
#include "RooFormulaVar.h"
#include "RooGenericPdf.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "TAxis.h"

#include "RooStats/ModelConfig.h"
#include "RooStats/ProfileLikelihoodCalculator.h"
#include "RooStats/LikelihoodInterval.h"
#include "RooStats/LikelihoodIntervalPlot.h"

using namespace RooFit;
using namespace RooStats;


void esercizio2(){

//Define observables
RooRealVar x("x","invariant mass", 110, 135, "GeV");
//Set number of bins
x.setBins(10);

//Read dataset
RooDataSet *data = RooDataSet::read("higgs_4l.dat",
                                    x, // variables to be read. If the file has more fields, these are ignored.
                                    "D"); // Prints if a RooFit message stream listens for debug messages. Use Q for quiet.
//Model
//Signal
RooRealVar mean("mean","m",110,150);
RooRealVar width("width","width",4.1/2.35);
RooRealVar alpha("alpha","alpha",0.6);
RooRealVar n("n","n",20);

RooCBShape sig("sig","signal",x,mean,width,alpha,n);

//Background

RooRealVar a1("a1", "The a1 of background", -160, -100, -200);
RooRealVar a2("a2", "The a2 of background", 2.7, 2, 4);

RooPolynomial bkg("bkg","background",x,RooArgList(a1,a2));

//Composite model
RooRealVar nsig("nsig","expected signal",23,0,200);
RooRealVar nbkg("nbkg","expected background",100,0,200);

RooAddPdf model("model","composite model",RooArgList(bkg,sig),RooArgList(nbkg,nsig));

//Fit the model to data

model.fitTo(*data);

//Plot
TCanvas *c1 = new TCanvas("c1");
RooPlot *xframe = x.frame();
data->plotOn(xframe);
model.plotOn(xframe);
xframe->Draw();

//import the model
RooWorkspace w("w");

w.import(nsig);
w.import(nbkg);
w.import(*data);
w.import(model);

//Constant parameters
w.var("mean")->setConstant(true);
w.var("width")->setConstant(true);
w.var("alpha")->setConstant(true);
w.var("n")->setConstant(true);

//Nuissance parameters
w.defineSet("nuisParams","nbkg,a1,a2"); 

//ModelConfig
ModelConfig mc("ModelConfig",&w);
mc.SetWorkspace(w);
// set components using the name of ws objects
mc.SetPdf("model");

mc.SetParametersOfInterest("nsig");
mc.SetObservables("x");
mc.SetNuisanceParameters(*w.set("nuisParams"));


//import modelconfig
w.import(mc);

//new nuissance parameters
w.defineSet("nuisParams2","nsig,width,nbkg,a1,a2");

//new mean parameter
w.var("mean")->setConstant(false);

//ModelConfig
ModelConfig mc_mass("ModelConfigMass",&w);
mc_mass.SetWorkspace(w);
// set components using the name of ws objects
mc_mass.SetPdf("model");
mc_mass.SetParametersOfInterest("mean");
mc_mass.SetObservables("x");
mc_mass.SetNuisanceParameters(*w.set("nuisParams2"));

w.import(mc_mass);
w.writeToFile("HiggsWorkspace.root");

//---------------------------


TCanvas *c2 = new TCanvas();
// create the class using data and model config
ProfileLikelihoodCalculator plc(*data, mc_mass); //mc and data are pointers

// set the confidence level
plc.SetConfidenceLevel(0.683);

// compute the interval of the parameter mu
LikelihoodInterval* interval = plc.GetInterval();
// print the interval (get a pointer of mu from M.C.)
auto poi = static_cast<RooRealVar*> (mc_mass.GetParametersOfInterest()->first());
double lowerLimit = interval->LowerLimit(*poi);
double upperLimit = interval->UpperLimit(*poi);

// plot the interval
LikelihoodIntervalPlot plot(interval);
plot.Draw();


//FeldmanCousins

FeldmanCousins fc(*data,mc_mass); 
fc.UseAdaptiveSampling(true);
fc.FluctuateNumDataEntries(false);
fc.SetNBins(10); // number of points to test per parameter fc.SetTestSize(.1);
fc.SetConfidenceLevel(0.9);
fc.CreateConfBelt(true);

PointSetInterval* interval_fc = fc.GetInterval();
ConfidenceBelt* belt = fc.GetConfidenceBelt();

// print out the iterval on the first Parameter of Interest
RooRealVar* firstPOI = (RooRealVar*) mc_mass.GetParametersOfInterest()->first();
cout << "\n90% interval on " <<firstPOI->GetName()<<" is : ["<<
interval_fc->LowerLimit(*firstPOI) << ", "<<
interval_fc->UpperLimit(*firstPOI) <<"] "<<endl;

//Hypothesis test

StandardHypoTestDemo("HiggsWorkspace.root","w","ModelConfig","","dataset",2, 3, 100);

}