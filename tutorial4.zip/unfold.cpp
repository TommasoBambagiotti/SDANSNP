#if !(defined(__CINT__) || defined(__CLING__)) || defined(__ACLIC__)
#include <iostream>
using std::cout;
using std::endl;

#include "TRandom.h"
#include "TH1D.h"
#include "TCanvas.h"

#include "RooUnfoldResponse.h"
#include "RooUnfoldBayes.h"
#include "RooUnfoldSvd.h"
#include "RooUnfoldTUnfold.h"
#include "RooUnfoldIds.h"
#endif


const double_t cutdummy = -99999.0;


double smear(double xt)
{
    double xeff = 0.3 + (1.0 - 0.3) / 20 * (xt + 10.0); // efficiency
    double x = gRandom->Rndm();
    if (x > xeff) {
    return cutdummy;
    }
    double xsmear = gRandom->Gaus(-2.5, 0.2); // bias and smear
    return xt + xsmear;
}

void unfold() {

//response matrix
RooUnfoldResponse response(40, -10.0, 10.0); 

// Train with a Breit-Wigner, mean 0.3 and width 2.5.
for (int i = 0; i < 100000; i++) {
//double_t xt = gRandom->BreitWigner(0.3, 2.5);
double_t xt = gRandom->Gaus(2, 2);
double x = smear(xt);
if (x != cutdummy) {
response.Fill(x, xt);
} else {
response.Miss(xt);
 }
}

auto responseMatrix = response.Mresponse(); // Response matrix as a :TMatrixD
// (row,column)=(measured,truth)
new TCanvas("response matrix","response matrix");
responseMatrix.Draw("colz");

//inverse response matrix
auto responseInv = *static_cast<TMatrixD*>(responseMatrix.Clone());
responseInv.Invert();

// plot the inverse
new TCanvas("inverted matrix","inverted matrix");
responseInv.Draw("colz");

//truth and meas histograms
TH1D* model_true = new TH1D("true", "Test Truth", 40, -10.0, 10.0);
TH1D* model_meas = new TH1D("meas", "Test Measured", 40, -10.0, 10.0);

for (int i = 0; i < 10000; i++) {
double xt = gRandom->Gaus(0.0, 2.0);
double x = smear(xt);
model_true->Fill(xt);
if (x != cutdummy) {
    model_meas->Fill(x);
    }
}


//Fill the histograms
auto model_meas_Rinv = static_cast<TH1D*>(model_meas->Clone("model_meas_Rinv"));
model_meas_Rinv->Reset();
for (int ibin = 1; ibin < model_meas_Rinv->GetNbinsX() + 1; ibin++) {
double matsum = 0;
for (int jbin = 1; jbin < model_meas_Rinv->GetNbinsX() + 1; jbin++) {
matsum +=
model_meas->GetBinContent(jbin) * responseInv[ibin - 1][jbin - 1];
}
model_meas_Rinv->SetBinContent(ibin, matsum);
}

//Plot matrix inversion approach
auto c4 = new TCanvas("", "matrix inversion approach");
c4->Divide(2, 2);
c4->cd(1); 
model_true->Draw("hist");
c4->cd(2);
model_meas->Draw("pe same");
model_meas_Rinv->SetLineColor(EColor::kOrange);
c4->cd(3);
model_meas_Rinv->Draw("histsame");
c4->cd(4);
model_meas_Rinv->Draw("hist");

//Unfolding
RooUnfoldBayes unfold_Bayes (&response,model_meas,4);

RooUnfoldIds unfold_Ids (&response, model_meas, 1);

 TH1D* hReco_Bayes= (TH1D*) unfold_Bayes.Hreco();
 TH1D* hReco_Ids = (TH1D*) unfold_Ids.Hreco();

//Plot Bayes and IDS
 auto c5 = new TCanvas("","unfold Bayes and Ids");
 c5->Divide(2,1);
 c5->cd(1);
   
 hReco_Bayes->Draw();
 model_meas->Draw("SAME");
 model_true->SetLineColor(8);
 model_true->Draw("SAME");

 c5->cd(2);
 hReco_Ids->Draw();
 model_meas->Draw("SAME");
 model_true->SetLineColor(8);
 model_true->Draw("SAME");

 c5->Draw();

}